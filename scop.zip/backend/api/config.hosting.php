<?php
return [
  // InfinityFree database credentials (update password to your vPanel password)
  'db_host' => 'sql113.infinityfree.com',
  'db_name' => 'if0_40042826_scop_db',
  'db_user' => 'if0_40042826',
  'db_pass' => 'YOUR_VPANEL_PASSWORD_HERE',
  'max_upload_bytes' => 26214400,
  'allowed_mime_types' => [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'image/jpeg',
    'image/png',
    'image/gif',
    'video/mp4',
    'text/plain'
  ],
  // Google Sign-In Client ID required by AuthController
  'google_client_id' => '614874768179-jeif5hfmlgs7f67mqct37t42soq7qhdg.apps.googleusercontent.com'
];