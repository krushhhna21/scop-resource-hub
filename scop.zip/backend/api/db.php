<?php
// db.php - PDO connection with environment-aware config selection
// Priority: config.local.php (explicit override) > config.hosting.php (non-local hosts or USE_HOSTING_CONFIG=1) > config.php (default)
<?php
// db.php - PDO connection (environment-aware)
// Prefer local override; else on non-local hosts or when USE_HOSTING_CONFIG=1, use hosting config if available
$configPath = __DIR__ . '/config.php';
if (file_exists(__DIR__ . '/config.local.php')) {
  $configPath = __DIR__ . '/config.local.php';
} else {
  $host = $_SERVER['HTTP_HOST'] ?? '';
  $isLocal = !$host || $host === 'localhost' || $host === '127.0.0.1';
  $useHosting = (getenv('USE_HOSTING_CONFIG') === '1');
  if ((!$isLocal || $useHosting) && file_exists(__DIR__ . '/config.hosting.php')) {
    $configPath = __DIR__ . '/config.hosting.php';
  }
}

$config = require $configPath;
try {
  $dsn = "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4";
  $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch (Exception $e) {
  http_response_code(500);
  header('Content-Type: application/json');
  echo json_encode(['error' => 'DB connection failed', 'details' => $e->getMessage()]);
  exit;
}
  $dsn = "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4";
  $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch (Exception $e) {
  http_response_code(500);
  header('Content-Type: application/json');
  echo json_encode(['error' => 'DB connection failed', 'details' => $e->getMessage()]);
  exit;
}
