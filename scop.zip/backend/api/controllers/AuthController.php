<?php
class AuthController {
  private $pdo;
  private $config;

  public function __construct(PDO $pdo, array $config) {
    $this->pdo = $pdo;
    $this->config = $config;
  }

  private function verifyIdToken(string $idToken): array {
    // Verify via Google tokeninfo endpoint (simple, server-side)
    $fetchTokenInfo = function(string $url) {
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_TIMEOUT, 10);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
      $resp = curl_exec($ch);
      $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      $err = curl_error($ch);
      curl_close($ch);
      return [$http, $resp, $err];
    };

    [$http, $resp, $err] = $fetchTokenInfo('https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($idToken));
    if ($http !== 200 || !$resp) {
      // Fallback older endpoint
      [$http2, $resp2, $err2] = $fetchTokenInfo('https://www.googleapis.com/oauth2/v3/tokeninfo?id_token=' . urlencode($idToken));
      if ($http2 === 200 && $resp2) { $resp = $resp2; $http = $http2; $err = $err2; }
    }
    $payload = $resp ? json_decode($resp, true) : null;

    $clientId = $this->config['google_client_id'] ?? null;
    if (!$clientId) throw new Exception('Server missing google_client_id config');

    if (!$payload || !isset($payload['aud'])) {
      // Dev fallback: decode JWT locally without signature validation for localhost only (opt-in)
      $allowDev = ($this->config['dev_allow_unverified_id_token'] ?? true) && isset($_SERVER['HTTP_HOST']) && (stripos($_SERVER['HTTP_HOST'], 'localhost') !== false || $_SERVER['HTTP_HOST'] === '127.0.0.1');
      if ($allowDev) {
        $parts = explode('.', $idToken);
        if (count($parts) >= 2) {
          $payloadJson = base64_decode(strtr($parts[1], '-_', '+/'));
          $payload = json_decode($payloadJson, true);
        }
      }
      if (!$payload || !isset($payload['aud'])) {
        $detail = $http ? (string)$http : 'no-http';
        throw new Exception('Failed to verify token with Google (' . $detail . ') ' . $err);
      }
    }

    if ($payload['aud'] !== $clientId) throw new Exception('Token audience mismatch');

    // Basic checks
    if (isset($payload['exp']) && time() > intval($payload['exp'])) throw new Exception('Token expired');
    if (isset($payload['email_verified']) && !$payload['email_verified']) throw new Exception('Email not verified');

    return $payload;
  }

  private function upsertUser(string $email, ?string $name): array {
    // Ensure users table exists (safe)
    $this->pdo->exec("CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(255),
      email VARCHAR(255) UNIQUE,
      password_hash VARCHAR(255),
      role ENUM('admin','faculty','student') DEFAULT 'student',
      display_name VARCHAR(255),
      is_active TINYINT(1) DEFAULT 1,
      is_approved TINYINT(1) DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $stmt = $this->pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
      // Update display_name if changed
      $dn = $user['display_name'] ?: '';
      if ($name && $name !== $dn) {
        $u = $this->pdo->prepare('UPDATE users SET display_name = ? WHERE id = ?');
        $u->execute([$name, $user['id']]);
        $user['display_name'] = $name;
      }
      return $user;
    }
    $ins = $this->pdo->prepare('INSERT INTO users (email, display_name, role, is_active, is_approved) VALUES (?, ?, "student", 1, 0)');
    $ins->execute([$email, $name]);
    $id = intval($this->pdo->lastInsertId());
    return [
      'id' => $id,
      'email' => $email,
      'display_name' => $name,
      'role' => 'student',
      'is_active' => 1,
      'is_approved' => 0,
    ];
  }

  public function loginWithGoogle() {
    $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $idToken = $payload['id_token'] ?? null;
    if (!$idToken) throw new Exception('id_token required');

    $google = $this->verifyIdToken($idToken);
    $email = $google['email'] ?? null;
    if (!$email) throw new Exception('No email in token');
    $name = $payload['display_name'] ?? ($google['name'] ?? ($google['given_name'] ?? null));
    $course = $payload['course'] ?? null;
    $batchYear = isset($payload['year']) ? intval($payload['year']) : (isset($payload['batch_year']) ? intval($payload['batch_year']) : null);

    $user = $this->upsertUser($email, $name);

    // Upsert student profile details (course, batch_year)
    try {
      $this->pdo->exec("CREATE TABLE IF NOT EXISTS student_profiles (
        user_id INT PRIMARY KEY,
        batch_year INT,
        linkedin_url VARCHAR(512),
        instagram_url VARCHAR(512),
        twitter_url VARCHAR(512),
        bio TEXT,
        avatar_url VARCHAR(512),
        course VARCHAR(128),
        CONSTRAINT fk_student_profiles_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      if ($course !== null || $batchYear !== null) {
        $st = $this->pdo->prepare("INSERT INTO student_profiles (user_id, batch_year, course) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE batch_year = VALUES(batch_year), course = VALUES(course)");
        $st->execute([$user['id'], $batchYear, $course]);
      }
    } catch (Throwable $e) {
      // Non-fatal for login
    }

    // Auto-approve/admin bootstrap: if email in config admin_emails, promote and approve
    $adminEmails = $this->config['admin_emails'] ?? [];
    if (is_string($adminEmails)) { $adminEmails = array_filter(array_map('trim', explode(',', $adminEmails))); }
    if (in_array($email, $adminEmails, true)) {
      $this->pdo->prepare("UPDATE users SET is_approved = 1, role = 'admin' WHERE email = ?")->execute([$email]);
      // refresh user snapshot
      $stmt = $this->pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
      $stmt->execute([$email]);
      $user = $stmt->fetch(PDO::FETCH_ASSOC) ?: $user;
    } else {
      // If no admin exists at all, auto-promote the first Google login to admin (safe bootstrap)
      $cnt = intval($this->pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn());
      if ($cnt === 0) {
        $this->pdo->prepare("UPDATE users SET is_approved = 1, role = 'admin' WHERE email = ?")->execute([$email]);
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC) ?: $user;
      }
    }
    $_SESSION['user'] = [
      'id' => intval($user['id']),
      'email' => $user['email'],
      'name' => $user['display_name'] ?? $name ?? 'Student',
      'role' => $user['role'] ?? 'student',
      'approved' => intval($user['is_approved'] ?? 0) === 1,
    ];

    return [
      'ok' => true,
      'user' => $_SESSION['user'],
    ];
  }

  public function status() {
    if (isset($_SESSION['user'])) {
      return ['authenticated' => true, 'user' => $_SESSION['user']];
    }
    return ['authenticated' => false];
  }

  public function logout() {
    unset($_SESSION['user']);
    return ['ok' => true];
  }
}
