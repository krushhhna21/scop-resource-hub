<?php
session_start();
header('Content-Type: application/json');

// Allow simple CORS for dev (adjust for prod)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET,POST,OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type');
  exit;
}
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/controllers/AdminController.php';
require_once __DIR__ . '/controllers/StudentController.php';
require_once __DIR__ . '/controllers/ChatController.php';
require_once __DIR__ . '/controllers/PublicationController.php';
require_once __DIR__ . '/controllers/DirectoryController.php';
require_once __DIR__ . '/controllers/VacancyController.php';
require_once __DIR__ . '/controllers/DiscussionController.php';
require_once __DIR__ . '/controllers/AuthController.php';

// Prefer local config override; otherwise, on non-local hosts use hosting config if present
$configPath = __DIR__ . '/config.php';
if (file_exists(__DIR__ . '/config.local.php')) {
  $configPath = __DIR__ . '/config.local.php';
} else {
  $host = $_SERVER['HTTP_HOST'] ?? '';
  $isLocal = !$host || $host === 'localhost' || $host === '127.0.0.1';
  $useHosting = (getenv('USE_HOSTING_CONFIG') === '1');
  if (( !$isLocal || $useHosting ) && file_exists(__DIR__ . '/config.hosting.php')) {
    $configPath = __DIR__ . '/config.hosting.php';
  }
}
$config = require $configPath;
$admin = new AdminController($pdo, $config);
$student = new StudentController($pdo);
$chat = new ChatController($config);
$pub = new PublicationController($pdo);
$dir = new DirectoryController($pdo);
$vac = new VacancyController($pdo);
$disc = new DiscussionController($pdo);
$auth = new AuthController($pdo, $config);

$action = $_GET['action'] ?? $_POST['action'] ?? null;

// Helper: require approved student session for resource endpoints
function require_approved_student() {
  if (!isset($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(['error' => 'auth_required']);
    exit;
  }
  if (!($_SESSION['user']['approved'] ?? false)) {
    http_response_code(403);
    echo json_encode(['error' => 'approval_required']);
    exit;
  }
}

function json_ok($data) { echo json_encode($data); exit; }
function json_err($msg, $code=400) { http_response_code($code); echo json_encode(['error' => $msg]); exit; }

try {
  switch ($action) {
    // Auth
    case 'auth_status':
      json_ok($auth->status());
      break;
    case 'auth_login_google':
      json_ok($auth->loginWithGoogle());
      break;
    case 'auth_logout':
      json_ok($auth->logout());
      break;
    // Public routes (students)
    case 'get_page_content':
      $slug = $_GET['slug'] ?? null;
      if (!$slug) json_err('slug is required');
      json_ok($student->getPageContent($slug));
      break;
    case 'list_years':
      require_approved_student();
      json_ok($student->listYears());
      break;
    case 'list_subjects':
      require_approved_student();
      $year_id = intval($_GET['year_id'] ?? 0);
      if (!$year_id) json_err('year_id is required');
      json_ok($student->listSubjects($year_id));
      break;
    case 'list_resources':
      require_approved_student();
      $subject_id = intval($_GET['subject_id'] ?? 0);
      $resource_type = $_GET['resource_type'] ?? 'resource';
      if (!$subject_id) json_err('subject_id is required');
      json_ok($student->listResources($subject_id, $resource_type));
      break;
    case 'list_resources_by_year':
      require_approved_student();
      $year_id = intval($_GET['year_id'] ?? 0);
      $resource_type = $_GET['resource_type'] ?? 'resource';
      if (!$year_id) json_err('year_id is required');
      json_ok($student->listResourcesByYear($year_id, $resource_type));
      break;
    case 'list_resources_by_type':
      require_approved_student();
      $resource_type = $_GET['resource_type'] ?? 'resource';
      json_ok($student->listResourcesByType($resource_type));
      break;
    case 'increment_view':
      $resource_id = intval($_POST['resource_id'] ?? 0);
      if (!$resource_id) json_err('resource_id is required');
      json_ok($student->incrementView($resource_id));
      break;

    // Admin routes
    case 'admin_login':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $u = $payload['username'] ?? null;
      $p = $payload['password'] ?? null;
      if (!$u || !$p) json_err('Missing credentials');
      json_ok($admin->login($u, $p));
      break;
    case 'admin_logout':
      json_ok($admin->logout());
      break;
    case 'admin_me':
      json_ok($admin->me());
      break;
    case 'admin_stats':
      json_ok($admin->stats());
      break;
    case 'admin_list_resources':
      $q = $_GET['q'] ?? null;
      json_ok($admin->listResources($q));
      break;
    case 'admin_create_resource':
      // Expect multipart/form-data
      $subject_id = intval($_POST['subject_id'] ?? 0);
      $year_id = intval($_POST['year_id'] ?? 0);
      $title = trim($_POST['title'] ?? '');
      $description = trim($_POST['description'] ?? '');
      $external_url = trim($_POST['external_url'] ?? '');
      $resource_type = trim($_POST['resource_type'] ?? 'resource');
      $card_color = trim($_POST['card_color'] ?? '#0ea5e9');
      
      // Validation based on resource type
      $general_types = ['journal', 'publication', 'career'];
      
      if ($resource_type === 'question') {
        // For questions (PYQ), subject_id is optional but year_id is required
        if (!$title || !$year_id) json_err('title and year_id are required for questions');
        $subject_id = $subject_id > 0 ? $subject_id : null;
      } elseif ($resource_type === 'important-question') {
        // For important questions, both subject_id and year_id are required (like books)
        if (!$subject_id || !$title || !$year_id) json_err('subject_id, year_id and title are required for important questions');
      } elseif (in_array($resource_type, $general_types)) {
        // For general resources, only title is required
        if (!$title) json_err('title is required');
        $subject_id = $subject_id > 0 ? $subject_id : null;
        $year_id = $year_id > 0 ? $year_id : null;
      } else {
        // For specific resources (books, etc.), subject_id and title are required
        if (!$subject_id || !$title) json_err('subject_id and title are required');
      }
      
      json_ok($admin->createResource($subject_id, $title, $description, $external_url, $resource_type, $year_id, $card_color));
      break;
    case 'admin_delete_resource':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $rid = intval($payload['resource_id'] ?? 0);
      if (!$rid) json_err('resource_id required');
      json_ok($admin->deleteResource($rid));
      break;

    case 'admin_set_page_content':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $slug = trim($payload['slug'] ?? '');
      $html = $payload['html'] ?? '';
      if ($slug === '') json_err('slug is required');
      json_ok($admin->setPageContent($slug, $html));
      break;

    case 'admin_list_pending_users':
      json_ok($admin->listPendingUsers());
      break;
    case 'admin_approve_user':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $uid = intval($payload['id'] ?? 0);
      if (!$uid) json_err('id required');
      json_ok($admin->approveUser($uid));
      break;

    // Helpers
    case 'list_all_subjects':
      json_ok($admin->listAllSubjects());
      break;

    case 'chat':
      $chat->chat();
      break;

    // Publications
    case 'list_publications':
      $q = $_GET['q'] ?? null;
      $ar = $_GET['author_role'] ?? null;
      $app = isset($_GET['approved']) ? intval($_GET['approved']) : null;
      json_ok($pub->listPublications($q, $ar, $app));
      break;
    case 'create_publication':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $title = trim($payload['title'] ?? '');
      $url = $payload['url'] ?? null;
      $author = $payload['author_name'] ?? null;
      $role = $payload['author_role'] ?? 'student';
      if ($title === '') json_err('title required');
      json_ok($pub->createPublication($title, $url, $author, $role));
      break;
    case 'approve_publication':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $id = intval($payload['id'] ?? 0);
      if (!$id) json_err('id required');
      json_ok($pub->approvePublication($id));
      break;
    case 'delete_publication':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $id = intval($payload['id'] ?? 0);
      if (!$id) json_err('id required');
      json_ok($pub->deletePublication($id));
      break;

    // Directory (students)
    case 'list_students':
      $q = $_GET['q'] ?? null;
      $batch = isset($_GET['batch']) ? intval($_GET['batch']) : null;
      json_ok($dir->listStudents($q, $batch));
      break;
    case 'upsert_student_profile':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $userId = intval($payload['user_id'] ?? 0);
      if (!$userId) json_err('user_id required');
      $batchYear = isset($payload['batch_year']) ? intval($payload['batch_year']) : null;
      $linkedin = $payload['linkedin_url'] ?? null;
      $instagram = $payload['instagram_url'] ?? null;
      $twitter = $payload['twitter_url'] ?? null;
      $bio = $payload['bio'] ?? null;
      $avatar = $payload['avatar_url'] ?? null;
      json_ok($dir->upsertStudentProfile($userId, $batchYear, $linkedin, $instagram, $twitter, $bio, $avatar));
      break;

    // Vacancies & Referrals
    case 'list_vacancies':
      $q = $_GET['q'] ?? null;
      $category = $_GET['category'] ?? null;
      $batch = isset($_GET['batch']) ? intval($_GET['batch']) : null;
      json_ok($vac->listVacancies($q, $category, $batch));
      break;
    case 'create_vacancy':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $title = trim($payload['title'] ?? '');
      if ($title === '') json_err('title required');
      $company = $payload['company'] ?? null;
      $location = $payload['location'] ?? null;
      $category = $payload['category'] ?? null;
      $description = $payload['description'] ?? null;
      $applicationLink = $payload['application_link'] ?? null;
      $postedBy = isset($payload['posted_by']) ? intval($payload['posted_by']) : null;
      $batchFilter = isset($payload['batch_filter']) ? intval($payload['batch_filter']) : null;
      json_ok($vac->createVacancy($title, $company, $location, $category, $description, $applicationLink, $postedBy, $batchFilter));
      break;
    case 'request_referral':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $vacancyId = intval($payload['vacancy_id'] ?? 0);
      $requesterId = intval($payload['requester_id'] ?? 0);
      if (!$vacancyId || !$requesterId) json_err('vacancy_id and requester_id required');
      $message = $payload['message'] ?? null;
      json_ok($vac->requestReferral($vacancyId, $requesterId, $message));
      break;

    // Discussions
    case 'list_channels':
      json_ok($disc->listChannels());
      break;
    case 'create_channel':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $name = trim($payload['name'] ?? '');
      if ($name === '') json_err('name required');
      $description = $payload['description'] ?? null;
      $visibility = $payload['visibility'] ?? 'public';
      $createdBy = isset($payload['created_by']) ? intval($payload['created_by']) : null;
      json_ok($disc->createChannel($name, $description, $visibility, $createdBy));
      break;
    case 'list_posts':
      $channelId = intval($_GET['channel_id'] ?? 0);
      if (!$channelId) json_err('channel_id required');
      $afterId = isset($_GET['after_id']) ? intval($_GET['after_id']) : null;
      json_ok($disc->listPosts($channelId, $afterId));
      break;
    case 'create_post':
      $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
      $channelId = intval($payload['channel_id'] ?? 0);
      if (!$channelId) json_err('channel_id required');
      $parentId = isset($payload['parent_id']) ? intval($payload['parent_id']) : null;
      $authorId = isset($payload['author_id']) ? intval($payload['author_id']) : null;
      $content = trim($payload['content'] ?? '');
      if ($content === '') json_err('content required');
      json_ok($disc->createPost($channelId, $parentId, $authorId, $content));
      break;

    default:
      json_err('Unknown action', 404);
  }
} catch (Exception $e) {
  json_err($e->getMessage(), 400);
}
